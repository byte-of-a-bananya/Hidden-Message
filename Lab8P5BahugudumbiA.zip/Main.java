import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Main{//LineReader Class
    public static void main(String[] args) throws FileNotFoundException{
        File input = new File("input.txt");

        //Scanner in = new Scanner(System.in);
        Scanner in = new Scanner(input);

        String hold = in.nextLine();
        int testCases = Integer.parseInt(hold);
        
        for(int z = 0; z < testCases; z++){
        hold = in.nextLine();
        int lines = Integer.parseInt(hold);
            String[] allLines = new String[lines];
            for(int k = 0; k < lines; k++){
               allLines[k] = in.nextLine();
               //System.out.println(allLines[k]);
            }
            
            hold = in.nextLine();
            
            int first = Integer.parseInt(hold.substring(0, hold.indexOf(",")));
            int second = Integer.parseInt(hold.substring(hold.indexOf(",")+1));
            
            int coverLines = Integer.parseInt(in.nextLine());
        
            String[] coverMessage = new String[coverLines];
            for(int p = 0; p<coverLines; p++){
                coverMessage[p] = in.nextLine();
            }
            
         ArrayMaker hohoho = new ArrayMaker(allLines, coverMessage, lines, coverLines, first, second );    
         String[][] firstMessage = hohoho.makeMessageArray();
         String[][] secondMessage = hohoho.makeCoverArray();
         
         /*for(int u = 0; u<firstMessage.length; u++){
             for(int k = 0; k<firstMessage[0].length; k++){
                 System.out.print(firstMessage[u][k]+" ");
                }
                System.out.println("");
          }*/
         
         Decrypter santa = new Decrypter(firstMessage, secondMessage, allLines, second);
         

         System.out.println(santa.decrypt());
        }
}
}