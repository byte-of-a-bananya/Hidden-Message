public class ArrayMaker{

    private int lines;
    private int first;
    private int second;
    private int coverLines;
    private String[] allLines;
    private String[] coverMessage;
    private int sunshine;
    
    public ArrayMaker(String[] allLines, String[] coverMessage, int lines, int coverLines, int first, int second){
        this.allLines = allLines;
        this.coverMessage = coverMessage;
        this.lines = lines;
        this.coverLines = coverLines;
        this.first = first;
        this.second = second;
    }
    
    public String[][] makeMessageArray(){
        int size = allLines[0].length();
        for(int k = 1; k<lines; k++){
            if(allLines[k].length()> size){
                size = allLines[k].length();
            }
        }
        String[][] firstMessageOriginal = new String[lines][size];
        
        for(int i = 0; i<lines; i++){
            for(int j= 0; j<allLines[i].length(); j++){
                firstMessageOriginal[i][j] = allLines[i].substring(j, j+1); 
            }
        }
    
        String[][] firstMessage = new String[lines-first][size-second];
        for(int i = first; i<lines; i++){
                //System.out.println(allLines[i].length());
            for(int j = second; j<allLines[i].length(); j++){
                firstMessage[i-first][j-second] = firstMessageOriginal[i][j];
            }
        }
        return firstMessage;
    }
    
    public String[][] makeCoverArray(){
        int size2 = coverMessage[0].length();
        for(int k = 1; k<coverLines; k++){
            if(coverMessage[k].length()> size2){
                size2 = coverMessage[k].length();
            }
        }
        String[][] secondMessage = new String[coverLines][size2];
        for(int i = 0; i<coverLines; i++){
            for(int j= 0; j<coverMessage[i].length(); j++){
                secondMessage[i][j] = coverMessage[i].substring(j, j+1);    
            }
        }
            return secondMessage;
    }
}