public class Decrypter{
	private String[][] firstMessage;
	private String[][] secondMessage;
	private String[] allLines;
	private String end;
	private int second;
	
	public Decrypter(String[][] firstMessage, String[][] secondMessage, String[] allLines, int second){
		this.firstMessage = firstMessage;
		this.secondMessage = secondMessage;
		this.allLines = allLines;
		this.end = "";
		this.second = second;
	}
	
	public String decrypt(){
		String hold = "";
		//System.out.println(firstMessage);
		//System.out.println(secondMessage);

		for(int i = 0; i<secondMessage.length; i++){
		    //System.out.println(firstMessage.length);
			int size = secondMessage[i].length;
			//System.out.println(size);
			for(int j = 0; j<size; j++){
				hold = secondMessage[i][j];
				//System.out.println(hold);
				if(!hold.equals("O")){
				    	//System.out.println("end: "+end);
					//end = end + firstMessage[i][j];
					//System.out.println("end: "+end);
				}
				else
				{
					end = end + firstMessage[i][j];
					//System.out.println("<");
					//System.out.println(firstMessage[i][j-1]);
					//System.out.println(firstMessage[i][j]);
					//System.out.println(firstMessage[i][j+1]);
					//System.out.println(">");
				}
			}
		}
		return end;
	}
}